# 8-puzzle-search-implementation
this a python BFS implementation of 8 puzzle.
please implement DFS and A* algorithms.
