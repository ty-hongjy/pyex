from queue import Queue
from puzzle import Puzzle


def depth_first_search(initial_state):
    """
    参考宽度优先搜索的代码，请在此处编写代码实现深度优先搜索
    """
    return
