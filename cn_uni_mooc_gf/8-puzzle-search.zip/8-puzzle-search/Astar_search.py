from queue import PriorityQueue
from puzzle import Puzzle


def Astar_search(initial_state):
    """
     参考宽度优先搜索的代码，请在此处编写代码实现A*搜索
     """
    return

